<?php
include('db.php');

if($_POST && $_POST['action']=='contest'){
    /* Ensure that the EMPLOYEES table exists. */
    verifyContestTable();
    /* If input fields are populated, add a row to the EMPLOYEES table. */
    $data = array();
    $data['name'] = htmlentities($_POST['name']);
    $data['EmployeeNo'] = htmlentities($_POST['EmployeeNo']); 
    $data['Region'] = htmlentities($_POST['Region']); 
    $data['msg'] = htmlentities($_POST['msg']);
    if($data['name']===''||$data['EmployeeNo']===''||$data['Region']===''||$data['msg']===''){
    echo json_encode(array('message'=>'Please fill all fields','status'=>'error')); 
    die();
    }
        addContest($data);
}

if($_GET['action']=='contest'){
   $contest = getContest();
   echo json_encode($contest);
}